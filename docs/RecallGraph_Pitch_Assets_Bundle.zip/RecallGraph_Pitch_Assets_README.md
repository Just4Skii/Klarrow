# Klarrow pitch assets - 17 October 2026

## Included
- `RecallGraph_Pitch_Deck.pptx` - editable 9-slide pitch deck with speaker notes.
- `RecallGraph_Pitch_Deck.pdf` - PDF rendering of the deck for quick review/sharing.
- `RecallGraph_Pitch_One_Pager.pdf` - single-page visual overview.
- `RecallGraph_Pitch_One_Pager.md` - editable source copy for the one-pager.
- `RecallGraph_Pitch_Deck_Outline.md` - slide-by-slide summary.
- `RecallGraph_5_Minute_Pitch_Script.md` - timed narration notes.

## Evidence discipline
The materials use the supplied Run 3 evidence: seven authored fictional documents; 13 Llama candidate facts plus 35 parser facts; 8 quote spans verbatim at cited lines and 5 identifier-only claims flagged; 8 relationship proposals with 7 confirmed and 1 rejected; final trace to FL-1021A and customers Bosveld and Highveld; and insufficient mass balance (320 kg received vs 180 kg recorded consumed plus 6,600 downstream units).

The deck explicitly states that four of the eight quote-verified spans did not contain the extracted value itself, that all 48 facts remained unreviewed at fact level during the run, and that the case is authored fiction. It does not claim customer validation, extraction accuracy, manual time savings, ERP integration, compliance or certification.

## Before submission
- Confirm the exact competition's current official eligibility, deadline, judging criteria and required pitch format; these materials are not tailored to a verified official rubric.
- Run a fresh application dry-run with the exact intended demo root and real Ollama model.
- Verify licence terms for the exact Llama model and competition requirements.
- Replace no benchmark numbers unless the new measurements and artifacts are preserved and checked.
